from flask import Flask, request, jsonify, render_template, send_file
from flask_cors import CORS
import speech_recognition as sr
import pyttsx3
import os
import re
import string
from nltk.tokenize import RegexpTokenizer
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
from sklearn.preprocessing import LabelEncoder
import uuid
import joblib
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
import tensorflow as tf
import pickle
from pydub import AudioSegment
import tempfile

app = Flask(__name__)
CORS(app)

BASE_DIR = "c:/Users/ranar/OneDrive/Desktop/Phonetic System/PhoneticFlowSystem"

# Define paths (all files in models folder)
model_path = os.path.join(BASE_DIR, "models", "BidirectionalLSTM.pt")
glove_path = os.path.join(BASE_DIR, "models", "glove.6B.300d.txt")
tokenizer_path = os.path.join(BASE_DIR, "models", "tokenizer.pkl")
label_encoder_path = os.path.join(BASE_DIR, "models", "label_encoder.pkl")


# Ensure necessary directories exist
UPLOAD_FOLDER = "uploads"
OUTPUT_FOLDER = "output"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)


# Define the sentimentBiLSTM class
class sentimentBiLSTM(torch.nn.Module):
    def __init__(self, embedding_matrix, hidden_dim, output_size):
        super(sentimentBiLSTM, self).__init__()
        self.embedding_matrix = embedding_matrix
        self.hidden_dim = hidden_dim
        num_words = self.embedding_matrix.shape[0]
        embed_dim = self.embedding_matrix.shape[1]
        self.embedding = torch.nn.Embedding(num_embeddings=num_words, embedding_dim=embed_dim)
        self.embedding.weight = torch.nn.Parameter(torch.tensor(embedding_matrix, dtype=torch.float32))
        self.embedding.weight.requires_grad = False
        self.lstm = torch.nn.LSTM(embed_dim, hidden_dim, bidirectional=True, batch_first=True)
        self.fc = torch.nn.Linear(hidden_dim * 2, output_size)
    
    def forward(self, x):
        embeds = self.embedding(x)
        lstm_out, _ = self.lstm(embeds)
        lstm_out = lstm_out[:, -1]
        out = self.fc(lstm_out)
        return out

# Load embedding matrix
def load_vectors(glove_file):
    embedding_dict = {}
    with open(glove_file, 'r', encoding='utf-8') as f:
        for line in f:
            values = line.split()
            word = values[0]
            vector = np.array(values[1:], dtype='float32')
            embedding_dict[word] = vector
    return embedding_dict

def create_embedding_matrix(word_index, embedding_dict, embedding_dim=300):
    embedding_matrix = np.zeros((len(word_index) + 1, embedding_dim))
    for word, i in word_index.items():
        embedding_vector = embedding_dict.get(word)
        if embedding_vector is not None:
            embedding_matrix[i] = embedding_vector
    return embedding_matrix

# Load tokenizer
with open(tokenizer_path, "rb") as f:
    tokenizer = pickle.load(f)

# Load embedding matrix
embedding_dict = load_vectors(glove_path)
embedding_matrix = create_embedding_matrix(tokenizer.word_index, embedding_dict)

# Parameters
hidden_dim = 64
output_size = 3
MAX_LEN = 167

# Initialize model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = sentimentBiLSTM(embedding_matrix, hidden_dim, output_size)
model.load_state_dict(torch.load(model_path, map_location=device))
model = model.to(device)
model.eval()
print("Model loaded successfully")

# Load label encoder
with open(label_encoder_path, "rb") as f:
    le = pickle.load(f)
print("LabelEncoder loaded. Classes:", le.classes_)

# Preprocessing functions
def clean_emoji(tx):
    emoji_pattern = re.compile("["
                               u"\U0001F600-\U0001F64F"
                               u"\U0001F300-\U0001F5FF"
                               u"\U0001F680-\U0001F6FF"
                               u"\U0001F1E0-\U0001F1FF"
                               u"\U00002702-\U000027B0"
                               u"\U000024C2-\U0001F251"
                               "]+", flags=re.UNICODE)
    return emoji_pattern.sub(r'', tx)

def text_cleaner(tx):
    text = re.sub(r"won\'t", "would not", tx)
    text = re.sub(r"im", "i am", tx)
    text = re.sub(r"Im", "I am", tx)
    text = re.sub(r"can\'t", "can not", text)
    text = re.sub(r"don\'t", "do not", text)
    text = re.sub(r"shouldn\'t", "should not", text)
    text = re.sub(r"needn\'t", "need not", text)
    text = re.sub(r"hasn\'t", "has not", text)
    text = re.sub(r"haven\'t", "have not", text)
    text = re.sub(r"weren\'t", "were not", text)
    text = re.sub(r"mightn\'t", "might not", text)
    text = re.sub(r"didn\'t", "did not", text)
    text = re.sub(r"n\'t", " not", text)
    text = re.sub(r"\'re", " are", text)
    text = re.sub(r"\'s", " is", text)
    text = re.sub(r"\'d", " would", text)
    text = re.sub(r"\'ll", " will", text)
    text = re.sub(r"\'t", " not", text)
    text = re.sub(r"\'ve", " have", text)
    text = re.sub(r"\'m", " am", text)
    text = re.sub(r'https?://\S+|www\.\S+', '', text)
    text = re.sub(r'[^a-zA-Z0-9\!\?\.\@]', ' ', text)
    text = re.sub(r'[!]+', '!', text)
    text = re.sub(r'[?]+', '?', text)
    text = re.sub(r'[.]+', '.', text)
    text = re.sub(r'[@]+', '@', text)
    text = re.sub(r'unk', ' ', text)
    text = re.sub(r'\n', '', text)
    text = text.lower()
    text = re.sub(r'[ ]+', ' ', text)
    return text

def stopwords_cleaner(text):
    stopwords_list = stopwords.words('english')
    sentiment_words = {'happy', 'awesome', 'love', 'great', 'sad', 'hate', 'bad', 'wonderful', 'amazing', 'fantastic', 'excellent'}
    word = [letter if letter in sentiment_words else Stemmer.stem(letter) for letter in text if letter not in stopwords_list]
    return ' '.join(word)

# Initialize tokenizer and stemmer
Tokenizer = RegexpTokenizer(r'\w+')
Stemmer = PorterStemmer()



@app.route('/')
def home():
    return render_template('home.html')

@app.route('/speech_to_text')
def speech_to_text():
    return render_template('speech_to_text.html')

@app.route('/text_to_speech')
def text_to_speech():
    return render_template('text_to_speech.html')

@app.route('/sentiment_analysis')
def sentiment_analysis():
    return render_template('sentiment_analysis.html')

@app.route('/transcribe', methods=['POST'])
def transcribe_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files['file']
    
    # Create a unique filename to avoid conflicts
    original_filename = f"original_{uuid.uuid4().hex}"
    original_path = os.path.join(UPLOAD_FOLDER, original_filename)
    file.save(original_path)

    # Print debug info
    print(f"Saved original file to {original_path}, size: {os.path.getsize(original_path)} bytes")
    print(f"File content type: {file.content_type}")
    
    try:
        # Convert the audio to WAV format using pydub
        wav_filename = f"converted_{uuid.uuid4().hex}.wav"
        wav_path = os.path.join(UPLOAD_FOLDER, wav_filename)
        
        # Determine the format based on content type
        format_hint = None
        if 'webm' in file.content_type:
            format_hint = 'webm'
        elif 'mp3' in file.content_type:
            format_hint = 'mp3'
        elif 'ogg' in file.content_type:
            format_hint = 'ogg'
        
        print(f"Attempting to convert from format: {format_hint or 'auto-detect'}")
        
        # Try to convert the audio
        try:
            if format_hint:
                audio = AudioSegment.from_file(original_path, format=format_hint)
            else:
                audio = AudioSegment.from_file(original_path)
            
            # Export as WAV
            audio.export(wav_path, format="wav")
            print(f"Converted to WAV: {wav_path}, size: {os.path.getsize(wav_path)} bytes")
        except Exception as conv_error:
            print(f"Conversion error: {str(conv_error)}")
            # If conversion fails, try different formats
            for fmt in ['webm', 'mp3', 'ogg', 'wav']:
                try:
                    print(f"Trying format: {fmt}")
                    audio = AudioSegment.from_file(original_path, format=fmt)
                    audio.export(wav_path, format="wav")
                    print(f"Successfully converted using format {fmt}")
                    break
                except Exception as e:
                    print(f"Failed with format {fmt}: {str(e)}")
            else:
                raise Exception("Could not convert audio to a supported format")
        
        # Now use the converted WAV file for transcription
        recognizer = sr.Recognizer()
        with sr.AudioFile(wav_path) as source:
            audio_data = recognizer.record(source)
            text = recognizer.recognize_google(audio_data)
            return jsonify({"text": text})
            
    except sr.UnknownValueError:
        return jsonify({"error": "Could not understand the audio"}), 400
    except sr.RequestError as e:
        return jsonify({"error": f"Google Speech Recognition service error: {e}"}), 500
    except Exception as e:
        return jsonify({"error": f"Error processing audio: {str(e)}"}), 500
    finally:
        # Clean up the files after processing
        if os.path.exists(original_path):
            os.remove(original_path)
        if 'wav_path' in locals() and os.path.exists(wav_path):
            os.remove(wav_path)

@app.route('/realtime-transcription', methods=['GET'])
def realtime_transcription():
    recognizer = sr.Recognizer()
    try:
        with sr.Microphone() as source:
            recognizer.adjust_for_ambient_noise(source)
            print("Listening for speech...")
            audio = recognizer.listen(source)
            try:
                text = recognizer.recognize_google(audio)
                return jsonify({"text": text})
            except sr.UnknownValueError:
                return jsonify({"error": "Could not understand the audio."}), 400
            except sr.RequestError as e:
                return jsonify({"error": f"Request error: {e}"}), 500
    except OSError as e:
        return jsonify({"error": f"Microphone not available: {e}"}), 500

@app.route('/download', methods=['POST'])
def download_text():
    data = request.json
    text = data.get('text', '')
    file_path = os.path.join(OUTPUT_FOLDER, 'transcription.txt')
    with open(file_path, 'w') as file:
        file.write(text)
    return send_file(file_path, as_attachment=True)

@app.route('/text-to-speech', methods=['POST'])
def text_to_speech_endpoint():
    data = request.get_json()
    text = data.get('text', '').strip()

    if not text:
        return jsonify({"error": "No text provided"}), 400

    try:
        engine = pyttsx3.init()
        engine.setProperty('rate', 150)
        engine.setProperty('volume', 1.0)

        # Generate a unique filename
        audio_filename = f"speech_{uuid.uuid4().hex}.wav"
        audio_path = os.path.join(OUTPUT_FOLDER, audio_filename)

        # Synthesize speech and save to file
        engine.save_to_file(text, audio_path)
        engine.runAndWait()

        # Verify the file exists
        if os.path.exists(audio_path):
            return send_file(
                audio_path,
                mimetype='audio/wav',
                as_attachment=True,
                download_name="speech_output.wav"
            )
        else:
            return jsonify({"error": "Speech file was not created."}), 500

    except Exception as e:
        return jsonify({"error": f"Server error: {str(e)}"}), 500
    


    
@app.route('/predict', methods=['POST'])
def predict():
    user_input = request.form['text']
    if not user_input.strip():
        return render_template('sentiment_analysis.html', prediction="Please enter a valid post.", probabilities=None)

    # Preprocess input
    cleaned_text = text_cleaner(user_input)
    cleaned_text = clean_emoji(cleaned_text)
    tokenized_text = Tokenizer.tokenize(cleaned_text)
    processed_text = stopwords_cleaner(tokenized_text)

    # Debugging outputs
    print(f"Original input: {user_input}")
    print(f"Cleaned text: {cleaned_text}")
    print(f"Tokenized text: {tokenized_text}")
    print(f"Processed text: {processed_text}")

    # Tokenize and pad
    sequence = tokenizer.texts_to_sequences([processed_text])
    print(f"Sequence: {sequence}")

    # Map token indices back to words for debugging
    reverse_word_index = {v: k for k, v in tokenizer.word_index.items()}
    decoded_sequence = [reverse_word_index.get(idx, '<OOV>') for idx in sequence[0]] if sequence[0] else []
    print(f"Decoded sequence: {decoded_sequence}")

    # Check embedding vectors for tokens
    for idx in sequence[0]:
        word = reverse_word_index.get(idx, '<OOV>')
        emb_vector = embedding_matrix[idx]
        norm = np.linalg.norm(emb_vector)
        print(f"Embedding for '{word}' (index={idx}): norm={norm:.3f}")

    padded = tf.keras.preprocessing.sequence.pad_sequences(sequence, maxlen=MAX_LEN)

    # Convert to tensor
    input_tensor = torch.tensor(padded, dtype=torch.long).to(device)

    # Predict
    with torch.no_grad():
        output = model(input_tensor)
        logits = output.cpu().numpy()[0]
        probabilities = torch.softmax(output, dim=1).cpu().numpy()[0]
        prediction = output.argmax(dim=1).item()

    # Debugging logits
    print(f"Raw logits: Negative={logits[0]:.3f}, Neutral={logits[1]:.3f}, Positive={logits[2]:.3f}")

    # Decode prediction
    sentiment = le.inverse_transform([prediction])[0]
    prob_dict = {
        'Positive': f"{probabilities[2]:.3f}",
        'Negative': f"{probabilities[0]:.3f}",
        'Neutral': f"{probabilities[1]:.3f}"
    }

    return render_template('sentiment_analysis.html', prediction=sentiment, probabilities=prob_dict, input_text=user_input)



if __name__ == '__main__':
    app.run(debug=True)
